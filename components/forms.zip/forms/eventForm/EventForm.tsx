"use client";

import { eventDefaultValues } from "@/constants";
import { addNewCategoryForm, eventFormValidationSchema } from "@/lib/validator";

import * as Yup from "yup";
import { Formik, Form, getActiveElement } from "formik";
import FormikControl from "../Formik/FormikControl";
import styles from "./eventForm.module.scss";
import { Button, useDisclosure } from "@chakra-ui/react";
import { useEffect, useState } from "react";
import { useEdgeStore } from "@/lib/edgestore";
import AddCategory from "./AddCategory";
import { createCategory, getAllCategories } from "@/lib/actions/category.action";
import { useRouter } from "next/navigation";
import { createEvent } from "@/lib/actions/event.action";

interface EventFormProps {
  userId: string;
  type: "create" | "update";
}

interface Option {
  label: string;
  value: string;
}

const isOnlinecheckOptions = {
  key: "Online",
  value: true,
};

const isFreecheckOptions = {
  key: "Free",
  value: true,
};

export default function EventForm({ userId, type }: EventFormProps) {
  const [image, setImage] = useState<File | null>(null);
  const [dropDownOptions, setDropDownOptions] = useState<Option[]>([ { label: "Add Category", value: "" },]);

  const router = useRouter();

  const { edgestore } = useEdgeStore();

  const { isOpen, onOpen, onClose } = useDisclosure();

  const initialValues = eventDefaultValues;

  const addCategory = () => {
    onOpen();
  };

  const addCategorySubmit = async(
    newCategory: Yup.InferType<typeof addNewCategoryForm>
  ) => {
    console.log(newCategory);
    onClose();
    const newCategoryDb = await createCategory(newCategory.category)
    console.log('newwwwwwwwwwwwwwwwwwwww',newCategoryDb)
    setDropDownOptions((prevState) => [
      ...prevState,
      { label: newCategoryDb.name, value: newCategoryDb._id },
    ]); 
  };

  const onSubmit = async (
    values: Yup.InferType<typeof eventFormValidationSchema>, { resetForm }: { resetForm: () => void }
  ) => {
    console.log(values);
    let res;
    if (image) {
      res = await edgestore.publicFiles.upload({
        file: image,
        onProgressChange: (progress) => {
          console.log(progress);
        },
      });
    }
    if(type == 'create') {
      try{
    
        const newEvent = await createEvent({
          event:{
            title: values.title,
            description: values.description,
            location: values.location,
            startDateTime: values.startDateTime,
            endDateTime: values.endDateTime,
            imageUrl: res?.url as string,
            categoryId: values.categoryId as string,
            isFree: values.isFree as boolean,
            price: values.price as number,
            url: values.url
          },
          userId,
          path: '/profile'
        })
  
        if(newEvent){
          resetForm();
          router.push(`/events/${newEvent._id}`)
        }
      } catch(error) {
        console.log(error)
      }
    }
  };

  useEffect(() => {
    const fetchCategories = async () => {
      const allCategories = await getAllCategories();
      console.log('categorieeees', allCategories);
      if (allCategories) {
        allCategories.map(({_id, name}:{_id: string, name: string}) => {
          setDropDownOptions((prevState) => [
            ...prevState,
            { label: name, value: _id },
          ]);
        });
      }
    };

    fetchCategories();
  }, []);

  return (
    <>
      <Formik
        initialValues={initialValues}
        validationSchema={eventFormValidationSchema}
        onSubmit={onSubmit}
      >
        {(formik) => (
          <Form className={styles.formContainer}>
            <div className={styles.fieldWrapper}>
              <FormikControl
                control="input"
                name="title"
                placeholder="Event Title"
                type="text"
                variant="filled"
                fieldStyle={styles.inputField}
                focusBorderColor="gray.400"
              />
              <FormikControl
                control="select"
                name="categoryId"
                placeholder="Category"
                variant="filled"
                fieldStyle={styles.selectField}
                focusBorderColor="gray.400"
                dropDownOptions={dropDownOptions}
                addCategory={addCategory}
              />
            </div>
            <div className={styles.fieldWrapper} style={{ height: "200px" }}>
              <FormikControl
                control="textarea"
                name="description"
                placeholder="Event Description"
                variant="filled"
                fieldStyle={styles.textAreaField}
                focusBorderColor="gray.400"
              />

              <FormikControl
                control="image"
                name="imageUrl"
                fieldStyle={styles.imageField}
                setImage={setImage}
              />
            </div>
            <div className={styles.checkWrapper}>
              <FormikControl
                control="checkbox"
                name="isOnline"
                checkOptions={isOnlinecheckOptions}
                fieldStyle={styles.checkBoxField}
              />
              <div className={styles.fieldWrapper}>
                <FormikControl
                  control="input"
                  name="location"
                  placeholder="Location"
                  type="text"
                  variant="filled"
                  fieldStyle={styles.inputField}
                  focusBorderColor="gray.400"
                  disabled={formik.values.isOnline === true}
                  icon="/assets/icons/location-grey.svg"
                  iconSize={20}
                />

                <FormikControl
                  control="input"
                  name="url"
                  placeholder="Url"
                  type="string"
                  variant="filled"
                  fieldStyle={styles.inputField}
                  disabled={formik.values.isOnline === false}
                  focusBorderColor="gray.400"
                  icon="/assets/icons/link.svg"
                  iconSize={20}
                />
              </div>
            </div>

            <div className={styles.fieldWrapper}>
              <FormikControl
                name="startDateTime"
                control="date"
                placeholder="Start Date : "
                fieldStyle={styles.datePicker}
                icon="/assets/icons/calendar.svg"
                iconSize={20}
              />

              <FormikControl
                name="endDateTime"
                control="date"
                placeholder="End Date : "
                fieldStyle={styles.datePicker}
                icon="/assets/icons/calendar.svg"
                iconSize={20}
              />
            </div>
            <div className={styles.checkWrapper}>
              <FormikControl
                control="checkbox"
                name="isFree"
                checkOptions={isFreecheckOptions}
                fieldStyle={styles.checkBoxField}
              />
              <div className={styles.fieldWrapper}>
                <FormikControl
                  control="input"
                  name="price"
                  placeholder="Price"
                  type="number"
                  variant="filled"
                  fieldStyle={styles.inputField}
                  disabled={formik.values.isFree === true}
                  focusBorderColor="gray.400"
                  icon="/assets/icons/rupee.svg"
                  iconSize={20}
                />
              </div>
            </div>

            <Button type="submit" borderRadius="full">
              Create Event
            </Button>
          </Form>
        )}
      </Formik>

      <AddCategory
        isOpen={isOpen}
        onClose={onClose}
        onOpen={onOpen}
        addCategorySubmit={addCategorySubmit}
        dropDownOptions={dropDownOptions}
      />
    </>
  );
}
